FORD TRUCK PARTS — FREE WEBSITE STARTER

Included:
- index.html: responsive one-page website
- README.txt: setup and publishing instructions

BEFORE PUBLISHING:
1. Open index.html in a text editor.
2. Find: ADD-YOUR-EMAIL@example.com
3. Replace it with your real business email address.
4. Update any wording, phone number, business address, inventory and shipping details.
5. Test the enquiry form. It opens the visitor's email app; it does not store orders online.

WHATSAPP:
Your WhatsApp number has not been provided yet. When you have it, a WhatsApp order button can be added using:
https://wa.me/1YOURNUMBER
Use the full international number with digits only (no +, spaces or dashes).

FREE PUBLISHING OPTION — GITHUB PAGES:
1. Create a free account at https://github.com
2. Create a new public repository named ford-truck-parts
3. Upload index.html (and this README if desired) to the repository's main branch.
4. Open Settings > Pages.
5. Under Build and deployment, choose Deploy from a branch.
6. Select branch main and folder /(root), then Save.
7. GitHub will provide a free website address, usually:
   https://YOUR-USERNAME.github.io/ford-truck-parts/

ALTERNATIVE:
Netlify offers a free plan and can publish a static site by uploading the site folder at https://app.netlify.com/drop

IMPORTANT LIMITATIONS:
- This is a free static starter website, not a full ecommerce checkout.
- It does not process card payments, calculate shipping, manage stock, or store customer orders.
- The enquiry form uses the visitor's email application and needs your real email address added.
- Product listings, photos, actual stock, prices, returns/shipping policies, and contact details should be added only after you confirm them.
- Make sure all listed parts, fitment information, condition and shipping claims are accurate.
