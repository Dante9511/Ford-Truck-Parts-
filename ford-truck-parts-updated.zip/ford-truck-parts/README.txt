FORD TRUCK PARTS — UPDATED WEBSITE

Files:
- index.html: responsive site with sample catalogue, local shopping cart and parts enquiry flow.
- README.txt: publishing and setup notes.

BEFORE PUBLISHING:
1. Replace ADD-YOUR-EMAIL@example.com in index.html with your real business email (it appears in two mailto links).
2. Create a free account at https://www.tawk.to/
3. In tawk.to, open Administration > Chat Widget > Widget Code and copy your unique widget script.
4. Paste the complete unique script immediately before </body> in index.html, replacing the LIVE CHAT INSTALLATION comment.
5. Add your WhatsApp number later if desired.

CART LIMITATIONS:
- Cart works in the visitor's browser and remembers selected items on that device.
- The displayed items are sample catalogue entries, not confirmed stock.
- All prices are "Price on request"; this is a parts enquiry cart, not paid checkout.
- The Submit parts enquiry button opens the visitor's email app. It does not send automatically or store orders.
- Real online payments, stock management, shipping rates, and order confirmations require a payment provider and order-management/backend service.

PUBLISH UPDATE:
Upload this new index.html to your existing GitHub repository, choose to replace the existing file, and commit the change. GitHub Pages will redeploy the same site URL.
